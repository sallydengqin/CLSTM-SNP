import os
import numpy as np
import pandas as pd
import re
import matplotlib.pyplot as plt
from itertools import chain
import gc
from time import time
from keras.callbacks import ModelCheckpoint
import nltk
import sklearn
import scipy.stats
from sklearn.metrics import make_scorer
# from sklearn.cross_validation import cross_val_score
# from sklearn.grid_search import RandomizedSearchCV
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RandomizedSearchCV
from keras.utils import plot_model
import sklearn_crfsuite
from sklearn_crfsuite import scorers
from sklearn_crfsuite import metrics
from sklearn_crfsuite.metrics import flat_classification_report
from keras.preprocessing.sequence import pad_sequences
from keras.models import Model, Input
from keras.layers import LSTMSNPCell, Embedding, Dense, TimeDistributed, Dropout, Conv1D
from keras.layers import Bidirectional, concatenate, SpatialDropout1D, GlobalMaxPooling1D
from keras.utils import to_categorical
from keras_contrib.layers import CRF
from keras import backend as K
import tensorflow as tf
import matplotlib.pyplot as plt
from keras.callbacks import EarlyStopping
from seqeval.metrics import precision_score, recall_score, f1_score, classification_report, accuracy_score

results = []



train_CoNLL03_sample = open('./data/train.txt')
train = [line for line in train_CoNLL03_sample]

dev_CoNLL03_sample = open('./data/dev.txt')
dev = [line for line in dev_CoNLL03_sample]

import re
def change_form(f):
    form = []
    temp = []
    for line in f:
        if len(line)==0 or line[0]=="\n":
            if len(temp) > 0:
                form.append(temp)
                temp = []
            continue
        feat = line.split(' ')
        feat[-1] = re.sub(r'\n', '', feat[-1])
        temp.append((feat[0],feat[1],feat[3]))
    return form

new_train = change_form(train)
new_dev = change_form(dev)

max_len_dev = -1
for sent in new_dev:
    if len(sent) > max_len_dev:
        max_len_dev = len(sent)
print(max_len_dev)

words = set()
tags = set()
max_len_sent = -1
for sent in new_train:
    for w in sent:
        words.add(w[0])
        tags.add(w[2])
    if len(sent) > max_len_sent:
        max_len_sent = len(sent)
words = list(words)
tags = list(tags)

print(max_len_sent)
print(len(words))

words.append("ENDPAD")
words.append("UNK")

n_words = len(words)
n_tags = len(tags)
print(n_words)


max_len = 53

print(len(new_train))
new_train = [s  for s in new_train if (len(s) <= 60)]
print(len(new_train))
print(max(len(sen) for sen in new_train)) 

word2idx = {w: i for i, w in enumerate(words)}
tag2idx = {t: i for i, t in enumerate(tags)}

X_tr = [[word2idx[w[0]] for w in s] for s in new_train]

X_te = []
for s in new_dev:
    temp = []
    for w in s:
        if w[0] in word2idx:
            temp.append(word2idx[w[0]])
        else:
            temp.append(word2idx['UNK'])
    X_te.append(temp)

X_train = pad_sequences(maxlen=max_len, sequences=X_tr, padding="post", value=n_words-1)
X_test = pad_sequences(maxlen=max_len, sequences=X_te, padding="post", value=n_words-1)

y_tr = [[tag2idx[w[2]] for w in s] for s in new_train]
y_te = [[tag2idx[w[2]] for w in s] for s in new_dev]

y_train = pad_sequences(maxlen=max_len, sequences=y_tr, padding="post", value=tag2idx["O"])
y_test = pad_sequences(maxlen=max_len, sequences=y_te, padding="post", value=tag2idx["O"])

y_train = [to_categorical(i, num_classes=n_tags) for i in y_train]
y_test = [to_categorical(i, num_classes=n_tags) for i in y_test]

input = Input(shape=(max_len,))
model = Embedding(input_dim=n_words, output_dim=50, input_length=max_len)(input)
model = Dropout(0.15)(model)
model = LSTMSNPCell(256,return_sequences=True, dropout=0.50, recurrent_dropout=0.25)(model)
out = TimeDistributed(Dense(n_tags, activation="softmax"))(model)  # softmax output layer

model = Model(input, out)
model.compile(optimizer='nadam', loss="categorical_crossentropy", metrics=["accuracy"])

model.summary()
plot_model(model, to_file='snplstm.png')

checkpointer = ModelCheckpoint(filepath = 'snplstm_model.h5',
                       verbose = 0,
                       mode = 'auto',
                       save_best_only = True,
                       monitor='val_loss')

early_stopping = EarlyStopping(monitor='val_loss', mode='auto',patience=50, verbose=2)

t0 = time()
history = model.fit(X_train, np.array(y_train), batch_size=32, epochs=100, validation_split=0.1, verbose=1,callbacks=[checkpointer,early_stopping])
train_time = time() - t0
print("train time: %0.3fs" % train_time)
hist = pd.DataFrame(history.history)

#plt.figure(figsize=(4,4))
#plt.plot(hist["acc"])
#plt.plot(hist["val_acc"])
#plt.show()

print("history.history.keys()",history.history.keys())

acc = history.history['acc']
val_acc = history.history['val_acc']
loss = history.history['loss']
val_loss = history.history['val_loss']
plt.figure(figsize = (8, 8))
epochs = range(1, len(acc) + 1)
plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.savefig('./Training and validation accuracy.jpg')
plt.legend()

plt.figure(figsize = (8, 8))
plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.savefig('./Training and validation loss.jpg')
plt.legend()
plt.show()

t0 = time()
test_pred = model.predict(X_test, verbose=1)
test_time = time() - t0
print("test time:  %0.3fs" % test_time)

idx2tag = {i: w for w, i in tag2idx.items()}

def pred2label(pred):
    out = []
    for pred_i in pred:
        out_i = []
        for p in pred_i:
            p_i = np.argmax(p)
            out_i.append(idx2tag[p_i].replace("PAD", "O"))
        out.append(out_i)
    return out
    
pred_labels = pred2label(test_pred)
test_labels = pred2label(y_test)
print("F1-score: {:.1%}".format(f1_score(test_labels, pred_labels)))
print(classification_report(test_labels, pred_labels))
print(flat_classification_report(test_labels, pred_labels))



