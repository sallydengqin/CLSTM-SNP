# Download

Download and store glove.6B.100d.txt form [Here](http://nlp.stanford.edu/data/glove.6B.zip)